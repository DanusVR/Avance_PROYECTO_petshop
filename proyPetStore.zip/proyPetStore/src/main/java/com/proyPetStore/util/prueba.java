package com.proyPetStore.util;

public class prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Conexion c = new Conexion();
		
		c.abrirConexion();
		c.cerrarConexion();

	}

}
